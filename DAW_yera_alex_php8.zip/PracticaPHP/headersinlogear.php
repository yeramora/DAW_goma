<?php

    echo"<header>
    <a href='index.php'><img src='logo.png' alt='icono' width='100' height='100'></a> 
    <p>Memories</p>
    <aside>
    <a href='MensajeLogin.php'><i class='fas fa-sign-in-alt' aria-hidden='true'>Login</i></a>
    <a href='FormRegistro.php'><i class='fa fa-user-circle' aria-hidden='true'>Registrarse</i></a>
    </aside>
    </header>"; 
?>