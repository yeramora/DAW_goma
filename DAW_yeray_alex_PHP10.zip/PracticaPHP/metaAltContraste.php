<meta charset="UTF-8">
<script src="Alexjs.js"></script>
    <script src="codigoyera.js"></script>
    <link rel="stylesheet" href="Coontraste.css" title="Contraste" media="screen">  
    <link rel="stylesheet" href="cssImprimir.css" media="print">
    <script src="https://kit.fontawesome.com/6b4ca2c1fd.js" crossorigin="anonymous"></script>